const jwt = require("jsonwebtoken");

module.exports = (req, res, next) => {

  const token = req.headers.authorization;

  if (!token) {
    return res.status(401).json({ message: "No token provided" });
  }

  try {

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    req.adminId = decoded.adminId;

    next();

  } catch (error) {
    res.status(401).json({ message: "Invalid token" });
  }

};